
Project Name : Code Crackers

Team members : 

1)	Nishanth Pininti ( nxp141730)2)	Sailesh Kolla ( sxk145331)3)	Vikram Vepuri (vxv141530).

Applications (both Main Application and Web service Application are developed using Yii2 framework of PHP.

Folders in this file :

1) basic - Web Services API

2) yii-application - Main Online Book store API 

3) ONLINE BOOK STORE_Report - Final Report



