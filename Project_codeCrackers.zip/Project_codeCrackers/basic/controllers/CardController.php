<?php

namespace app\controllers;

class CardController extends \yii\rest\ActiveController
{
   public $modelClass = 'app\models\BillingInfo';
 

}
