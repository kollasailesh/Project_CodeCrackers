<?php

namespace app\controllers;

class AddcartController extends \yii\rest\ActiveController
{
   public $modelClass = 'app\models\Cart';
}
