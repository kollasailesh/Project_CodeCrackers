<?php

namespace app\controllers;
use app\models\Book;
use app\models\ElasticBook;
class SearchController extends \yii\rest\ActiveController
{
	public $modelClass = 'app\models\Elasticbook';
	public function actions()
	{
		$actions = parent::actions();
		unset($actions['index']);
	    unset($actions['create']);
		return $actions;
	}
    public function actionIndex()
    {
    	
    	Elasticbook::deleteAll();
    	$query = Book::find()->all();
    	foreach($query as $q)
    	{
    		$book = new Elasticbook();
    		$book->primaryKey = $q->book_id;
    		$book->attributes = ['book_id'=>$q->book_id,'book_isbn' => $q->book_isbn, 'book_category' => $q->book_category,'book_desc' => $q->book_desc,'book_price' => $q->book_price, 'item_photo_front' => $q->item_photo_front,'item_available_qnt' => $q->item_available_qnt,'item_discountPer' => $q->item_discountPer];;
    		$book->save();
    		
    		
    	}
    	$val = $_POST['searchV'];
    	$model = $this->modelClass;
    	$result = Elasticbook::find()->query(["match" => ["book_desc" => midnight]])->all();
    	//$result = ["searchV" => "great"];
    	return $result;
        

    	var_dump($result);
    	//return  $this->render('index', ['model' => $result
                
         //   ]);
    }
    public function actionCreate()
    {
   	$val = $_POST['searchV'];
    	$model = $this->modelClass;
    	$result = Elasticbook::find()->query(["match" => ["book_desc" => $val]])->all();
    /*	$result = Elasticbook::find()->query([
    			"fuzzy_like_this" => [
    					"fields" => ["Elasticbook.book_desc"],
    					"like_text" => $val,
    					"max_query_terms" => 12
    			]
    	]);*/
    	//$result = ["searchV" => "great"];
    	return $result;
    }

}
