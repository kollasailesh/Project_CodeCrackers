<?php

namespace app\controllers;

class CartBookController extends \yii\rest\ActiveController
{
public $modelClass = 'app\models\cart';
	public function actionCreate()
	{
		$val = $_POST['searchV'];
		$model = $this->modelClass;
		$result = Elasticbook::find()->query(["match" => ["book_desc" => $val]])->all();
		
		return $result;
	}

}
