<?php

namespace app\controllers;

class OrderdetailController extends \yii\rest\ActiveController
{
   public $modelClass = 'app\models\OrderDetails';
}
