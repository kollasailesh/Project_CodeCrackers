<?php

namespace app\controllers;

class CustomerController extends \yii\rest\ActiveController
{
   public $modelClass = 'app\models\Customer';

}
