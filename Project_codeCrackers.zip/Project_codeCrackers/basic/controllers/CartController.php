<?php

namespace app\controllers;
use app\models\Cart;
use app\models\Book;
use Yii;
class CartController extends \yii\rest\ActiveController
{
	public $modelClass = 'app\models\Book';
	public function actions()
	{
		$actions = parent::actions();
		unset($actions['index']);
		unset($actions['create']);
		return $actions;
	}
	public function actionCreate()
	{
		$val = $_POST['customerId'];
		
		$cach = Yii::$app->cache->MemCache->get($val);
		if($cach== false)
		{
		$res = Cart::find()->where(["customer_email_id" => $val])->all();
		Yii::$app->cache->MemCache->set($val,$res);
		}
		else {
			$res = $cach;
		}
		$result[] = null;
		$res = Cart::find()->where(["customer_email_id" => $val])->all();
		foreach($res as $s)
		{
			$result[] = Book::find()->where(["book_id" => $s->book_id])->one();
		}
		return $result;
	}

}
