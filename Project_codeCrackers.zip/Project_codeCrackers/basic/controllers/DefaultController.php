<?php

namespace app\controllers;

class DefaultController extends \yii\rest\ActiveController
{
	public $modelClass = 'app\models\User';

}
