<?php

namespace app\controllers;
use app\models\Cart;
class DeletecartController extends \yii\rest\ActiveController
{
	public $modelClass = 'app\models\Cart';
	public function actions()
	{
		$actions = parent::actions();
		unset($actions['index']);
		unset($actions['create']);
		return $actions;
	}
	public function actionCreate()
	{
		$mail_id = $_POST['customer_email_id'];
		$book_id = $_POST['book_id'];
		$model = $this->modelClass;
		$result = Cart::deleteAll(['customer_email_id' => $mail_id,'book_id' => $book_id]);
		Yii::$app->cache->MemCache->delete();
		return $result;
	}

}
