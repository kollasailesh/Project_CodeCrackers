<?php

namespace app\controllers;

use app\models\BillingInfo;
class GetbillingController extends \yii\rest\ActiveController
{
	public $modelClass = 'app\models\BillingInfo';
public function actions()
	{
		$actions = parent::actions();
		unset($actions['index']);
		unset($actions['create']);
		return $actions;
	}
	public function actionCreate()
	{
		$mail_id = $_POST['customer_email_id'];
		
		$model = $this->modelClass;
		$result = BillingInfo::find()->where(['customer_email_id' => $mail_id])->all();
	
		return $result;
	}
}
