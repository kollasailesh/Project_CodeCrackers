<?php

namespace app\controllers;

class AuthorController extends \yii\rest\ActiveController
{
   public $modelClass = 'app\models\Author';

}
