<?php
/* @var $this yii\web\View */
var_dump($model);
?>

