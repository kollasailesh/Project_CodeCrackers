<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "book".
 *
 * @property integer $book_id
 * @property integer $book_author_id
 * @property string $book_isbn
 * @property string $book_category
 * @property string $book_price
 * @property string $book_desc
 * @property string $item_photo_front
 * @property integer $item_available_qnt
 * @property string $item_discountPer
 *
 * @property Author $bookAuthor
 */
class Elasticbook extends \yii\elasticsearch\ActiveRecord
{
    /**
     * @inheritdoc
     */
	public function attributes()
    {
    	// path mapping for '_id' is setup to field 'id'
    	return ['book_id','book_author_id','book_isbn','book_category','book_desc','book_price','item_photo_front','item_available_qnt','item_discountPer'];
    }
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            //[['book_id'], 'required'],
            [['book_author_id', 'item_available_qnt'], 'integer'],
            [['book_price', 'item_discountPer'], 'number'],
            [['book_desc', 'item_photo_front'], 'string'],
            [['book_isbn'], 'string'],
            [['book_category'], 'string']
        ];
    }
    public static function active($query)
    {
    	$query->andWhere(['status' => 1]);
    }

}
