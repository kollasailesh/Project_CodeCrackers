<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "customer".
 *
 * @property string $customer_email_id
 * @property string $customer_first_name
 * @property string $customer_last_name
 * @property string $customer_address1
 * @property string $customer_address2
 * @property string $customer_gender
 * @property string $customer_from
 * @property string $customer_birthdate
 *
 * @property User $customerEmail
 */
class Customer extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'customer';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['customer_email_id', 'customer_first_name', 'customer_last_name', 'customer_gender'], 'required'],
            [['customer_birthdate'], 'safe'],
            [['customer_email_id'], 'string', 'max' => 45],
            [['customer_first_name'], 'string', 'max' => 50],
            [['customer_last_name'], 'string', 'max' => 80],
            [['customer_address1', 'customer_address2', 'customer_from'], 'string', 'max' => 100],
            [['customer_gender'], 'string', 'max' => 1]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'customer_email_id' => 'Customer Email ID',
            'customer_first_name' => 'Customer First Name',
            'customer_last_name' => 'Customer Last Name',
            'customer_address1' => 'Customer Address1',
            'customer_address2' => 'Customer Address2',
            'customer_gender' => 'Customer Gender',
            'customer_from' => 'Customer From',
            'customer_birthdate' => 'Customer Birthdate',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerEmail()
    {
        return $this->hasOne(User::className(), ['user_email_id' => 'customer_email_id']);
    }
}
