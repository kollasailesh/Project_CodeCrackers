<?php

namespace frontend\modules\cart\controllers;

use yii\web\Controller;
use frontend\models\Customer;
use frontend\modules\cart\models\BillingInfo;
use frontend\modules\cart\models\Order;
use frontend\modules\cart\models\OrderDetails;
 use Yii;
class DefaultController extends Controller
{
	public $enableCsrfValidation = false;
	public $layout = "@app/views/layouts/bookmain";
    public function actionIndex()
    {
        return $this->render('index');
    }
    
    
    public function actionAddcart()
    {		 
    	session_start();
    	$data = ["customerId" => $_SESSION['customer_email_id']];
    	//$data = null;
    	$book = (new Customer())->CallAPI("POST","http://localhost/basic/web/carts",$data);
    	$json = json_decode($book,true);
    		return $this->render('addcart',['book_details'=> $json]);
    }
    public function actionTocart()
    {
    	session_start();
    	$data = ["customer_email_id" => $_SESSION['customer_email_id'],"book_id" => $_POST['bookid']];
    	$book = (new Customer())->CallAPI("POST","http://localhost/basic/web/addcarts",$data);
    	$json = json_decode($book,true);
    	var_dump($json);
    }
    public function actionDeletecart()
    {
    	session_start();
    	$book_id = $_POST['id'];
    	$data = ["customer_email_id" => $_SESSION['customer_email_id'],"book_id" => $book_id];
    	$book = (new Customer())->CallAPI("POST","http://localhost/basic/web/deletecarts",$data);
    	$json = json_decode($book,true);
    	var_dump($json);
    	
    }
    public function actionCheckout()
    {
    	session_start();
    	$model1 = new BillingInfo();
    	
    	//$customer = Customer::find()->where(['customer_email_id' => $_SESSION['customer_email_id']])->one();
    	//$model = BillingInfo::find()->where(['customer_email_id' => $_SESSION['customer_email_id']])->all();
    	//session_start();
    	$cust = (new Customer())->CallAPI("GET","http://localhost/basic/web/customers/".$_SESSION['customer_email_id']);
    	$data = ['customer_email_id' => $_SESSION['customer_email_id']];
    	$mod = (new Customer())->CallAPI("POST","http://localhost/basic/web/getbillings",$data);
    	$customer = json_decode($cust,true);
    	$model = json_decode($mod,true);
    	$totalPrice = $_POST['total-price'];
    	$quantity = [];
    	//$item_details = unserialize($_POST['item_details']);
    	//$items = unserialize($_POST['items']);
    	$item_details = $_SESSION['book_details'];
    	$count =0;
    	foreach($item_details as $itemDetails)
    	{
    		if($count==0)
    		{
    			$count++;
    			continue;
    			
    		}
    		$quantity[$itemDetails['book_id']] = $_POST['quantity-text-field-'.$itemDetails['book_id']];
    		if($quantity[$itemDetails['book_id']] =='')
    			$quantity[$itemDetails['book_id']] = "1";
    	}
    	
    	
    	return $this->render('checkout',['model1' => $model1,'model' => $model, 'cust' => $customer,'item_details' => $item_details,'totalPrice' => $totalPrice,'quantity' => $quantity]);
    	
    }
    public function actionCard()
    {
    	$session = Yii::$app->session;
    	$session->open();
    	$model1 = new BillingInfo();
    	//$model1->customer_usr_name = $session['customer_name'];
    	$model1->customer_email_id = $_SESSION['customer_email_id'];
    	if ($model1->load(Yii::$app->request->post()) && $model1->validate()) {
    	
    		$card = (new Customer())->CallAPI("POST","http://localhost/basic/web/cards",$model1->toArray());
    		$card = json_decode($card,true);
    		echo $card["billing_id"].'_'.$card["creditcard_no"].'_'.$card["name_on_card"].'_'.$card["creditcard_expdate"];
    		// echo $card;
    }
    }
    
    public function actionCart()
    {
    	print_r("great");
    	//session_start();
    	$message = 'You Are Successfully Ordered';
    	if ($_SERVER["REQUEST_METHOD"] == "POST") {
           $session = Yii::$app->session;
    	$session->open();
    		$address = $_POST["address"];
    		$billing = $_POST["billingInfo"];
    		$totalPrice = $_POST["total-price"];
    		$quantity = $_SESSION['quantity'];
    		
    		$item_details = $_SESSION['item_details'];
    		$quantity = $_SESSION['quantity'];
    		//print_r($address);
    		//$billingInfo = BillingInfo::find()->where(['billing_id' => $billing])->one();
    		$card = (new Customer())->CallAPI("GET","http://localhost/basic/web/cards/".$billing);
    		var_dump($billing);
    		$billingInfo = json_decode($card,true);
    		$order = new Order();
    		$order->customer_email_id = $billingInfo['customer_email_id'];
    		$order->order_date = date("Y-m-d");
    		$order->billing_address = $billingInfo['billing_address'];
    		$order->creditcard_expdate = $billingInfo['creditcard_expdate'];
    		$order->name_on_card = $billingInfo['name_on_card'];
    		
    		$order->totalprice = $totalPrice;
    	    
    		$webs = (new Customer())->CallAPI("POST","http://localhost/basic/web/orders",$order->toArray());
    		$res = json_decode($webs,true);
    		//var_dump($res);
    		$count = 0;
    		foreach($item_details as $itemDetails)
    		{
    			 if($count==0)
    			 {
    			 	$count++;
    			 	continue;
    			 }
    			$order_details = new OrderDetails();
    			$order_details->order_id = $res['order_id'];
    			$order_details->book_id = $itemDetails['book_id'];
    			$order_details->quantity = intval($quantity[$itemDetails['book_id']]);
    			$order_details->order_status = 'pending';
    			$new = (new Customer())->CallAPI("POST","http://localhost/basic/web/orderdetails",$order_details->toArray());
    		}
    		 
    	}
    	 return $this->render('ordered',[]);
    	//return $this->render('ordered',[ 'address' => $address,'billing' => $billing,'billinginfo' => $billingInfo]);
    }
    }

