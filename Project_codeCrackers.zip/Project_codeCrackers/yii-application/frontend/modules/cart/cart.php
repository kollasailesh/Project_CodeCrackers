<?php

namespace frontend\modules\cart;

class cart extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\cart\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
