<?php

namespace frontend\modules\cart\models;

use Yii;

/**
 * This is the model class for table "cart".
 *
 * @property string $customer_email_id
 * @property integer $book_id
 *
 * @property Customer $customerEmail
 * @property Book $book
 */
class Cart extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cart';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['customer_email_id', 'book_id'], 'required'],
            [['book_id'], 'integer'],
            [['customer_email_id'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'customer_email_id' => 'Customer Email ID',
            'book_id' => 'Book ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerEmail()
    {
        return $this->hasOne(Customer::className(), ['customer_email_id' => 'customer_email_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBook()
    {
        return $this->hasOne(Book::className(), ['book_id' => 'book_id']);
    }
}
