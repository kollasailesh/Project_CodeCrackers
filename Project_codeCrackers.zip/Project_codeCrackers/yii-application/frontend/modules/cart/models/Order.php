<?php

namespace frontend\modules\cart\models;

use Yii;

/**
 * This is the model class for table "order".
 *
 * @property integer $order_id
 * @property string $customer_email_id
 * @property string $order_date
 * @property string $order_ship_date
 * @property string $billing_address
 * @property string $creditcard_expdate
 * @property string $name_on_card
 * @property string $shipping_address
 * @property string $totalprice
 * @property string $delivery_type
 *
 * @property Customer $customerEmail
 * @property OrderDetails[] $orderDetails
 * @property Book[] $books
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'order';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['customer_email_id'], 'required'],
            [['order_date', 'order_ship_date', 'creditcard_expdate'], 'safe'],
            [['customer_email_id', 'totalprice'], 'string', 'max' => 45],
            [['billing_address', 'shipping_address'], 'string', 'max' => 80],
            [['name_on_card'], 'string', 'max' => 40],
            [['delivery_type'], 'string', 'max' => 2]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'order_id' => 'Order ID',
            'customer_email_id' => 'Customer Email ID',
            'order_date' => 'Order Date',
            'order_ship_date' => 'Order Ship Date',
            'billing_address' => 'Billing Address',
            'creditcard_expdate' => 'Creditcard Expdate',
            'name_on_card' => 'Name On Card',
            'shipping_address' => 'Shipping Address',
            'totalprice' => 'Totalprice',
            'delivery_type' => 'Delivery Type',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerEmail()
    {
        return $this->hasOne(Customer::className(), ['customer_email_id' => 'customer_email_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderDetails()
    {
        return $this->hasMany(OrderDetails::className(), ['order_id' => 'order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBooks()
    {
        return $this->hasMany(Book::className(), ['book_id' => 'book_id'])->viaTable('order_details', ['order_id' => 'order_id']);
    }
}
