<?php
namespace frontend\controllers;


use frontend\models\Book;
use frontend\models\Customer;
use frontend\models\User;
use Yii;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\Session;
use yii\web\UploadedFile;

/**
 * Site controller
 */
class SiteController extends Controller
{
	public $enableCsrfValidation = false;
    /**
     * @inheritdoc
     */
	//public $layout = "bookmain.php";
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'signup'],
                'rules' => [
                    [
                        'actions' => ['signup'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Logs in a user.
     *
     * @return mixed
     */
    public function actionLogin()
    {
      

        $model = new User();
        if ($model->load(Yii::$app->request->post())) {
        	if($model->user_email_id == "admin@gmail.com" && $model->user_password == "admin")
        	{
        		return $this->redirect("index.php?r=site/admin");
        	}
        	else {
        	$result = (new Customer())->CallAPI("GET","http://localhost/basic/web/defaults/".$model->user_email_id);
        	$json = json_decode($result,true);
        	
        	//Yii::$app->session->setFlash('success',);
        	//return $this->redirect("index.php?r=site/login");
        	if(isset($json['user_email_id']))
        	{
        	if($json['user_email_id']==$model->user_email_id && $json['user_password'] == $model->user_password)
        	{
        		$session = new Session;
        		$session->open();
        		$session['customer_email_id'] = $model->user_email_id;
        		return $this->redirect("index.php?r=site/book",["id"=>302]);
        		
        	}
        	else
        	{
        		//session_start();
        		Yii::$app->session->setFlash('success',"Please enter the Correct Credentitials or Signup");
        		return $this->redirect("index.php?r=site/login");
        		
        	}
        	}
        	else {
        		Yii::$app->session->setFlash('success',"Please enter the Correct Credentitials or Signup");
        		return $this->redirect("index.php?r=site/login");
        		
        	}
        	}
           
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }
    public function actionAdmin()
    {
    	$model = new Book();
    	
    	if ($model->load(Yii::$app->request->post()) && $model->validate()) {
    		$image = UploadedFile::getInstance($model,'book_image');
	
    	//	echo \Yii::$app->basePath.'/web/bookimages/'.$im->name;
    	//echo $model->book_image->baseName;
    		$image->saveAs(\Yii::$app->basePath.'/web/bookimages/'.$image->baseName.'.'.$image->extension);
    		//$model->item_photo_front->saveAs( 'bookimages/'.$im->name.'.'.$im->extension );
    		//$model->save();
    		$model->item_photo_front = 'bookimages/'.$image->baseName.'.'.$image->extension;
    		$arr = (array) $model;
    		$result = (new Customer())->CallAPI("POST","http://localhost/basic/web/books",$model->toArray());
    		return $this->redirect("index.php?r=site/admin",["id"=>302]);
    		
    	}
    	else 
    	return	$this->render('admin',['model' => $model]);
    }
    public function actionSearch()
    {
    	$res = $_POST['search'];
    	//var_dump("pppppppppp".$res);
    	$this->layout = "bookmain";
    	$data = ['searchV' => $res];
    	$result = (new Customer())->CallAPI("POST","http://localhost/basic/web/searches",$data);
    	$json = json_decode($result,true);
    	//var_dump($json);
    	return $this->render('books',['books' => $json]);
    }
    public function actionBook()
    { 
    	$this->layout = "bookmain";	
    	$model = new Book();
    	$result = (new Customer())->CallAPI("GET","http://localhost/basic/web/books");
    	$json = json_decode($result,true);
    	
    	return $this->render('books',['books' => $json]);
    	
    	
    }
    /**
     * Logs out the current user.
     *
     * @return mixed
     */
    public function actionLogout()
    {
        session_destroy();

         return $this->redirect("index.php?r=site/login",["id"=>302]);
    }

  

    
   
    /**
     * Signs user up.
     *
     * @return mixed
     */
    public function actionSignup()
    {
        $model = new Customer();
        $session = new Session();
        $session->open();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $user = new User();
            $user->user_email_id = $model->customer_email_id;
            $user->user_password = $model->password;
            $data = ["user_email_id" => $model->customer_email_id,"user_password" => $model->password];
            $result = (new Customer())->CallAPI("GET","http://localhost/basic/web/defaults/".$model->customer_email_id);
            $json = json_decode($result,true);
            //var_dump($json);
            if(isset($json['status']))
            {
            (new Customer())->CallAPI("POST","http://localhost/basic/web/defaults",$data);	
            
            $res =(new Customer())->CallAPI("POST","http://localhost/basic/web/customers",$model->toArray());
            Yii::$app->session->setFlash('success','Thank you for registering, Please login');
            		//'You have succesfully registered!! Please Login to enter the site.');
            
            return $this->redirect("index.php?r=site/login",["id"=>302]);
            }
            else {
            	Yii::$app->session->setFlash('success','You have already registered!! Please Login to enter the site.');
            	return $this->redirect("index.php?r=site/login",["id"=>302]);
            }
            
         /* if(!User::find()
    ->where( [ 'user_email_id' => $model->customer_email_id ] )
    ->exists())
           {
           	$model->save();
           	print_r("greattttt");
           	$model->save();
           	Yii::$app->session->setFlash('success', 'You have successfully registered!! Please Login to continue.');
           	return $this->redirect("index.php?r=site/login",["id"=>302]);
           }
           else 
           {
           	Yii::$app->session->setFlash('success', 'You have already registered!! Please Login to enter the site.');
           	return $this->redirect("index.php?r=site/login",["id"=>302]);
           	
           }*/
           	
        }

        return $this->render('signup', [
            'customerModel' => $model,
        ]);
    }

    

}
