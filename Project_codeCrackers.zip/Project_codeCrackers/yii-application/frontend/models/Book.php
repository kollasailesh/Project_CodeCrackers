<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "book".
 *
 * @property integer $book_id
 * @property string $book_author_name
 * @property string $book_isbn
 * @property string $book_category
 * @property string $book_price
 * @property string $book_desc
 * @property string $item_photo_front
 * @property integer $item_available_qnt
 * @property string $item_discountPer
 *
 * @property Cart[] $carts
 * @property Customer[] $customerEmails
 * @property OrderDetails[] $orderDetails
 * @property Order[] $orders
 */
class Book extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'book';
    }
    
 public $book_image;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['book_author_name', 'book_isbn', 'book_category', 'book_price', 'item_available_qnt'], 'required'],
            [['book_price', 'item_discountPer'], 'number'],
            [['book_desc', 'item_photo_front'], 'string'],
            [['item_available_qnt'], 'integer'],
            [['book_author_name'], 'string', 'max' => 45],
            [['book_isbn'], 'string', 'max' => 13],
            [['book_category'], 'string', 'max' => 15],
        		[['book_image'],'file','extensions' => 'png, jpg'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'book_id' => 'Book ID',
            'book_author_name' => 'Book Author Name',
            'book_isbn' => 'Book Isbn',
            'book_category' => 'Book Category',
            'book_price' => 'Book Price',
            'book_desc' => 'Book Desc',
            'item_photo_front' => 'Item Photo Front',
            'item_available_qnt' => 'Item Available Qnt',
            'item_discountPer' => 'Item Discount Per',
        		
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCarts()
    {
        return $this->hasMany(Cart::className(), ['book_id' => 'book_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCustomerEmails()
    {
        return $this->hasMany(Customer::className(), ['customer_email_id' => 'customer_email_id'])->viaTable('cart', ['book_id' => 'book_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderDetails()
    {
        return $this->hasMany(OrderDetails::className(), ['book_id' => 'book_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Order::className(), ['order_id' => 'order_id'])->viaTable('order_details', ['book_id' => 'book_id']);
    }
}
