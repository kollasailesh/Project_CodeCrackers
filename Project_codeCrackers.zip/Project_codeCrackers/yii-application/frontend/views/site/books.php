<?php

$this->beginContent('/frontend/views/layouts/bookmain.php'); 
$this->title = 'Book Store';
$this->params['breadcrumbs'][] = $this->title;
//var_dump($books);
?>

<?php 
/*for($i=0;$i<sizeof($books);$i++)
{
	Echo '<div class="col-md-5>';
	Echo '<p><img src='.$books[$i]["item_photo_front"].' height="150px" border="5" ></p>';
	Echo '</div>';	
}*/
?>


<div class="panal">
<div class="panal-body">
<?php 
foreach($books as $book)
{
?>
<div class="col-md-3 col-sm-4 col-xs-6">
<div class="panal" style="height: 300px; text-align: center">
<div>
<img src=<?=$book["item_photo_front"]?> height="150px" border="5" >
</div>
<div style="min-height: 30px">
<h5> <?php echo $book["book_desc"]?></h5>
</div>
<div style="text-align: center">
<h4><?php echo $book["book_price"]?></h4>
</div>
<div style="text-align: center">
<a href="#" class="btn btn-success cart"  data-cart=<?php echo $book["book_id"]?>>
<i class="glyphicon glyphicon-plus"></i>Add to Cart</a>
</div>
</div>
</div>
<?php }?>
</div>
</div>
<?php 
$script = <<< JS

$(document).ready(function() {                        
                $('.cart').click(function(event) {
                    event.preventDefault();   
		alert('add to cart');
                    var username= $(this).attr('data-cart');
		data1 = "bookid="+username;
		            $.ajax({
    type: "POST",
    url: "index.php?r=cart/default/tocart",
    data: data1 ,
    success: function(result) {
		
		
    alert('success');
		}
		});
		});
		});

JS;
$this->registerJs($script);
?>
